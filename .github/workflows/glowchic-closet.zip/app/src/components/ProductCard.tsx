import { Star, ShoppingCart, ExternalLink } from 'lucide-react';
import type { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      if (i <= Math.floor(rating)) {
        stars.push(<Star key={i} className="w-3.5 h-3.5 fill-[#FFB800] text-[#FFB800]" />);
      } else if (i === Math.ceil(rating) && !Number.isInteger(rating)) {
        stars.push(
          <span key={i} className="relative">
            <Star className="w-3.5 h-3.5 text-[#E0E0E0]" />
            <span className="absolute inset-0 overflow-hidden w-1/2">
              <Star className="w-3.5 h-3.5 fill-[#FFB800] text-[#FFB800]" />
            </span>
          </span>
        );
      } else {
        stars.push(<Star key={i} className="w-3.5 h-3.5 text-[#E0E0E0]" />);
      }
    }
    return stars;
  };

  return (
    <div className="product-card group">
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#F0EEEC]">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.badge && (
            <span className="category-badge">
              {product.badge}
            </span>
          )}
          {product.discount && (
            <span className="discount-badge">
              -{product.discount}%
            </span>
          )}
        </div>

        {/* Prime Badge */}
        {product.isPrime && (
          <div className="absolute top-3 right-3 bg-[#00A8E1] text-white text-xs font-bold px-2 py-1 rounded">
            prime
          </div>
        )}

        {/* Quick Actions Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
          <a
            href={product.amazonLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-12 h-12 bg-white rounded-full flex items-center justify-center hover:bg-[#D4A5A5] transition-colors"
            aria-label="View on Amazon"
          >
            <ExternalLink className="w-5 h-5 text-[#111111]" />
          </a>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category */}
        <span className="font-mono text-[10px] uppercase tracking-wider text-[#6F6F6F]">
          {product.category.replace('-', ' ')}
        </span>

        {/* Title */}
        <h3 className="font-medium text-sm text-[#111111] mt-1 line-clamp-2 min-h-[40px]">
          {product.title}
        </h3>

        {/* Description */}
        <p className="text-xs text-[#6F6F6F] mt-2 line-clamp-2">
          {product.description}
        </p>

        {/* Rating */}
        <div className="flex items-center gap-2 mt-3">
          <div className="flex items-center gap-0.5">
            {renderStars(product.rating)}
          </div>
          <span className="text-xs text-[#6F6F6F]">
            ({product.reviewCount.toLocaleString()})
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2 mt-3">
          <span className="price-tag">₹{product.price.toLocaleString()}</span>
          {product.originalPrice && (
            <>
              <span className="price-original">
                ₹{product.originalPrice.toLocaleString()}
              </span>
            </>
          )}
        </div>

        {/* CTA Button */}
        <a
          href={product.amazonLink}
          target="_blank"
          rel="noopener noreferrer"
          className="amazon-btn w-full justify-center mt-4"
        >
          <ShoppingCart className="w-4 h-4" />
          Buy on Amazon
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
