import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag, Search, Heart } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Shop', path: '/category/all' },
    { name: 'Collections', path: '/category/party-wear' },
    { name: 'Blog', path: '/blog' },
    { name: 'About', path: '/about' },
  ];

  const categories = [
    { name: 'Party Wear', path: '/category/party-wear' },
    { name: 'Casual', path: '/category/casual' },
    { name: 'Western', path: '/category/western' },
    { name: 'Ethnic', path: '/category/ethnic' },
    { name: 'Summer', path: '/category/summer' },
    { name: 'Bodycon', path: '/category/bodycon' },
    { name: 'Maxi', path: '/category/maxi' },
    { name: 'Mini', path: '/category/mini' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#F6F4F2]/95 backdrop-blur-md shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2">
              <span className="font-display text-2xl font-bold tracking-tight text-[#111111]">
                GlowChic
              </span>
              <span className="font-display text-2xl font-light text-[#D4A5A5]">
                Closet
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`font-medium text-sm tracking-wide transition-colors ${
                    location.pathname === link.path
                      ? 'text-[#D4A5A5]'
                      : 'text-[#111111] hover:text-[#D4A5A5]'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
              <button className="hidden md:flex p-2 hover:bg-[#D4A5A5]/10 rounded-full transition-colors">
                <Search className="w-5 h-5 text-[#111111]" />
              </button>
              <button className="hidden md:flex p-2 hover:bg-[#D4A5A5]/10 rounded-full transition-colors">
                <Heart className="w-5 h-5 text-[#111111]" />
              </button>
              <button className="flex p-2 hover:bg-[#D4A5A5]/10 rounded-full transition-colors relative">
                <ShoppingBag className="w-5 h-5 text-[#111111]" />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#D4A5A5] rounded-full text-xs font-semibold flex items-center justify-center text-[#111111]">
                  0
                </span>
              </button>
              <button
                className="lg:hidden p-2 hover:bg-[#D4A5A5]/10 rounded-full transition-colors"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6 text-[#111111]" />
                ) : (
                  <Menu className="w-6 h-6 text-[#111111]" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 bg-[#F6F4F2] transition-transform duration-500 lg:hidden ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="pt-24 px-6 pb-8 h-full overflow-y-auto">
          <div className="space-y-6">
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#6F6F6F] mb-4">
                Navigation
              </h3>
              <div className="space-y-3">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    className="block font-display text-2xl font-semibold text-[#111111] hover:text-[#D4A5A5] transition-colors"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </div>

            <div className="border-t border-[#111111]/10 pt-6">
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#6F6F6F] mb-4">
                Categories
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {categories.map((cat) => (
                  <Link
                    key={cat.name}
                    to={cat.path}
                    className="font-medium text-[#111111] hover:text-[#D4A5A5] transition-colors"
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            </div>

            <div className="border-t border-[#111111]/10 pt-6">
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#6F6F6F] mb-4">
                Legal
              </h3>
              <div className="space-y-2">
                <Link
                  to="/privacy"
                  className="block text-sm text-[#6F6F6F] hover:text-[#D4A5A5] transition-colors"
                >
                  Privacy Policy
                </Link>
                <Link
                  to="/terms"
                  className="block text-sm text-[#6F6F6F] hover:text-[#D4A5A5] transition-colors"
                >
                  Terms & Conditions
                </Link>
                <Link
                  to="/affiliate-disclosure"
                  className="block text-sm text-[#6F6F6F] hover:text-[#D4A5A5] transition-colors"
                >
                  Affiliate Disclosure
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
