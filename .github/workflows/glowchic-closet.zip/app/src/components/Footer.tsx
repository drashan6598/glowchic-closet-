import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Youtube, Mail, MapPin, Phone } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    shop: [
      { name: 'New Arrivals', path: '/category/all' },
      { name: 'Party Wear', path: '/category/party-wear' },
      { name: 'Casual Dresses', path: '/category/casual' },
      { name: 'Western Wear', path: '/category/western' },
      { name: 'Ethnic Collection', path: '/category/ethnic' },
    ],
    company: [
      { name: 'About Us', path: '/about' },
      { name: 'Contact', path: '/contact' },
      { name: 'Blog', path: '/blog' },
      { name: 'Careers', path: '#' },
    ],
    support: [
      { name: 'Help Center', path: '#' },
      { name: 'Shipping Info', path: '#' },
      { name: 'Returns', path: '#' },
      { name: 'Size Guide', path: '#' },
    ],
    legal: [
      { name: 'Privacy Policy', path: '/privacy' },
      { name: 'Terms & Conditions', path: '/terms' },
      { name: 'Affiliate Disclosure', path: '/affiliate-disclosure' },
    ],
  };

  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Youtube, href: '#', label: 'YouTube' },
  ];

  return (
    <footer className="bg-[#111111] text-[#F6F4F2] pt-16 pb-8">
      <div className="w-full px-6 lg:px-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link to="/" className="inline-block mb-6">
              <span className="font-display text-3xl font-bold tracking-tight">
                GlowChic
              </span>
              <span className="font-display text-3xl font-light text-[#D4A5A5]">
                Closet
              </span>
            </Link>
            <p className="text-[#F6F4F2]/70 text-sm leading-relaxed mb-6 max-w-sm">
              Your ultimate destination for trendy women and girls dresses in India. 
              Discover the latest fashion at affordable prices with Amazon's trusted delivery.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-sm text-[#F6F4F2]/70">
                <Mail className="w-4 h-4 text-[#D4A5A5]" />
                <span>hello@glowchiccloset.com</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-[#F6F4F2]/70">
                <Phone className="w-4 h-4 text-[#D4A5A5]" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-[#F6F4F2]/70">
                <MapPin className="w-4 h-4 text-[#D4A5A5]" />
                <span>Mumbai, Maharashtra, India</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full bg-[#F6F4F2]/10 flex items-center justify-center hover:bg-[#D4A5A5] transition-colors group"
                >
                  <social.icon className="w-5 h-5 text-[#F6F4F2] group-hover:text-[#111111] transition-colors" />
                </a>
              ))}
            </div>
          </div>

          {/* Shop Links */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider mb-5">
              Shop
            </h4>
            <ul className="space-y-3">
              {footerLinks.shop.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="text-sm text-[#F6F4F2]/70 hover:text-[#D4A5A5] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider mb-5">
              Company
            </h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="text-sm text-[#F6F4F2]/70 hover:text-[#D4A5A5] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="font-display font-semibold text-sm uppercase tracking-wider mb-5">
              Support
            </h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="text-sm text-[#F6F4F2]/70 hover:text-[#D4A5A5] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Affiliate Disclosure Banner */}
        <div className="border-t border-[#F6F4F2]/10 pt-6 mb-6">
          <div className="bg-[#F6F4F2]/5 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <h5 className="font-semibold text-sm mb-1">Affiliate Disclosure</h5>
              <p className="text-xs text-[#F6F4F2]/60">
                GlowChic Closet is a participant in the Amazon Associates Program. 
                We earn a commission when you purchase through our links.
              </p>
            </div>
            <Link
              to="/affiliate-disclosure"
              className="text-xs text-[#D4A5A5] hover:underline whitespace-nowrap"
            >
              Learn More →
            </Link>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-[#F6F4F2]/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#F6F4F2]/50 text-center md:text-left">
            © {currentYear} GlowChic Closet. All rights reserved. 
            Designed with 💕 for fashion lovers in India.
          </p>
          <div className="flex items-center gap-6">
            {footerLinks.legal.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-xs text-[#F6F4F2]/50 hover:text-[#D4A5A5] transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
